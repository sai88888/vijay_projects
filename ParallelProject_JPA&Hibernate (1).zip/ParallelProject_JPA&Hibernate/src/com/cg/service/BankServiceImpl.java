package com.cg.service;

import com.cg.entity.BankDetails;

public interface BankServiceImpl {

	public   BankDetails getAccountById(int id);

	public   void createAccount(BankDetails bank);

	public   void showBalance(BankDetails bank);

	public  void deposit(BankDetails bank);
	
	public void withdraw(BankDetails bank);
	
	public void printTransactions(int id);

	public  void commitTransaction();

	public void beginTransaction();

}




