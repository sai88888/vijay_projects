package com.cg.dao;
import java.util.HashMap;

import com.cg.bean.BankBean;



public class BankDao implements BankDaoImpl {


		HashMap hMap;

		public BankDao() {

			hMap = new HashMap();
		}

		// bean class object

		BankBean bean = new BankBean();

		// to check account already exists or not

		public BankBean checkAccount(long accNo) {

			if (hMap.containsKey(accNo)) {

				bean = (BankBean) hMap.get(accNo);
				return bean;

			} else

				return null;
		}

		// to put the data into the map

		public void setData(long accNo, BankBean bean) {

			hMap.put(accNo, bean);
		}

	}


