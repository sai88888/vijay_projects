package com.cg.dao;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
public class DaoTest  {BankDao bd = new BankDao();	
	@Test
   public void Search()
	{
	assertTrue("This will succeed.", true);
    assertTrue("This will fail!", false);
	}

}
