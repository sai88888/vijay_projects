package com.cg.client;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entity.bankEntity;
import com.cg.entity.transactionEntity;
import com.cg.service.bankService;
public class Client {
	
	 
		public static void main(String[] args) {
			
		Scanner scan  = new Scanner(System.in);      
           ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
   		bankService bankService =  context.getBean("bankService",bankService.class);
	   String str;
			int c,balance;
			String choice,name,password,phoneNo;
			
			while(true)
			{
				System.out.println("***********Welcome to BankApp*************");

				System.out.println("Enter 1 to Create Account");
				System.out.println("Enter 2 to Show Balance");
				System.out.println("Enter 3 to Deposit Balance");
				System.out.println("Enter 4 to Withdraw Money");
				System.out.println("Enter 5 for Fund transfer");
				System.out.println("Enter 6 for Print transaction");
				System.out.println("Enter 7 for Exit");
				
	          	
					System.out.println("Enter Your choice : ");
				 str = scan.next();
				
				
				if(str.matches("[a-z]*")||str.matches("[A-Z]*"))
				{	     
					System.out.println("Invalid Choice!!!");
					main(null);
	            }
				
				
				switch (str) {
				case "1":


					System.out.println("Welcome to BankApp");


					do
					{
						System.out.println("Enter your name");
						name = scan.next();
						c =bankService.nameValidate(name);
					}
					while(c!=1);
					
					
					do
					{
						System.out.println("Enter your phone number");
						phoneNo = scan.next();
						c = bankService.mobNoValidate(phoneNo);
					}
					while(c!=1);
	                 
					long phone1 = Long.parseLong(phoneNo);
					long accountNo = phone1 + 1;

					do
					{
						System.out.println("Create password");
						password = scan.next();
						c = bankService.passwordValidate(password);
					}
					while(c!=1);

					do
					{
						System.out.println("Enter balance");
						balance = scan.nextInt();
						c = bankService.checkBalance(balance);
					}
					while(c!=1);
					
					boolean result =  bankService.createAccount(name,phoneNo,password,accountNo,balance);
					if(result)
					{
						System.out.println("Account created successful: "+accountNo);
					}
					break;

				case "2":

					System.out.println("Enter your account number");
					accountNo = scan.nextLong();
					System.out.println("Enter your password");
					password = scan.next();
					boolean b1= bankService.validateAccount(accountNo,password);
					if(b1)
					{
							balance = bankService.showBalance(accountNo);
							if(balance!=0)
							{
								System.out.println("Your account balance is "+balance);
							}
							else
							{
								System.out.println("Problem ");
							}
					}
					else
					{
						System.out.println("wrong credentials");
					}

					break;
				case "3":
					System.out.println("Enter your account number");
					accountNo = scan.nextLong();
					System.out.println("Enter your password");
					password = scan.next();
					boolean b= bankService.validateAccount(accountNo,password);
					if(b)
					{
						System.out.println("Enter the amount to be deposited");
						int deposit = scan.nextInt();
						balance = bankService.depositAmount(accountNo,deposit);
						System.out.println("Amount deposited");
						System.out.println("your new balance is "+balance);
					}
					else
					{
						System.out.println("wrong credentials");
					}
					break;
				case "4":

					System.out.println("Enter your account number");
					accountNo = scan.nextLong();
					System.out.println("Enter your password");
					password = scan.next();
					b= bankService.validateAccount(accountNo,password);
					if(b)
					{
						balance = bankService.showBalance(accountNo);
						System.out.println("Your current balance is "+balance);
						System.out.println("Enter the amount to be withdrawal");
						int withdraw = scan.nextInt();
							balance = bankService.withdrawAmount(accountNo,withdraw);
							if(balance>=0)
							{
								System.out.println("Amount withdrawal");
								System.out.println("You debited "+withdraw);
								System.out.println("your new balance is "+balance+"\n");
							}
							else
							{
                                 System.out.println("Insufficient funds");
							}
						}
						
					
					else
					{
				               System.out.println("wrong credential");
					}
					break;
					
				case "5":

					System.out.println("Enter your account number");
					accountNo = scan.nextLong();
					System.out.println("Enter your password");
					password = scan.next();
					b= bankService.validateAccount(accountNo,password);
					if(b)
					{
						System.out.println("\nEnter account no to transfer");
						long  accno = scan.nextLong();
						System.out.println("Enter the amount you want to transfer");
						int amount = scan.nextInt();
						boolean transfer = bankService.fundTransfer(accountNo, accno, amount);
						if(transfer)
						{
							System.out.println(amount+ " is transferred successfully\n");
						}
						else
						{
						  System.out.println("Problem in transfer");
						}
					}
					else
					{
						System.out.println("Invalid account");
					}

					break;
				case "6":
					System.out.println("Enter your account number");
					accountNo = scan.nextLong();
					System.out.println("Enter your password");
					password = scan.next();
					b= bankService.validateAccount(accountNo,password);
					if(b)
					{
	                    List<transactionEntity> trans=bankService.getTransaction(accountNo);

						System.out.println("----------Account Statement----------\n");

						for(transactionEntity tran:trans)
						{
							System.out.println(tran);
						}

					}
					else 
					{
						System.out.println("Account does not exist!");
					}
					break;
					
				case "7": 
					System.out.println("Thanku for visiting");
					System.exit(0);
				}

			}
	
	}

}
