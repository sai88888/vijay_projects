package com.cg.dao;

import com.cg.bean.BankBean;

public interface BankDaoImpl {

	public BankBean checkAccount(long accNo);

	public void setData(long accNo, BankBean bean);

}
