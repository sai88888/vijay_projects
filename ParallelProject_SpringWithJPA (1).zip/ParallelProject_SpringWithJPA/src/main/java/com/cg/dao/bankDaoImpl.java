package com.cg.dao;

import java.util.List;

import com.cg.entity.bankEntity;
import com.cg.entity.transactionEntity;

public interface bankDaoImpl {
   boolean createAccount(bankEntity bank);
   int showBalance(long accountNo);
   int depositBalance(long accountNo, int deposit);
   int withdrawAmount(long accountNo, int withdraw) ;
   boolean fundTransfer(long accountNo, long accno, int amount);
   boolean validateAccount(long accountNo,String password);
	public List<transactionEntity> getTransactions(long accountNo) ;
	


}
